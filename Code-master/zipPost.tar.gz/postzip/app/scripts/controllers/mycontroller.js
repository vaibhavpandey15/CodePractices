'use strict';

/**
 * @ngdoc function
 * @name yoangApp.controller:MycontrollerCtrl
 * @description
 * # MycontrollerCtrl
 * Controller of the yoangApp
 */
angular.module('yoangApp')
  .controller('MycontrollerCtrl',($scope,myfactory)=>{
		$scope.doSearch=()=>{
			var promise = myfactory.callServer($scope.search);
			promise.then((data)=>{
				$scope.result = data.data.PostOffice;
				console.log(data);
				},(err)=>{
				$scope.result = err;
				console.log("Get the Err in Promise...");
			})
			
		}
	});
